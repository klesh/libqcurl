#!/bin/sh

service ssh start
tail -f /dev/null
