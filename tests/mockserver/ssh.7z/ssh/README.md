# Login info of sftpuser
username: sftpuser
password: sftppass

# Login info of sftpkey
username: sftpkey
privatekey: id_rsa
privatekey password: pass
